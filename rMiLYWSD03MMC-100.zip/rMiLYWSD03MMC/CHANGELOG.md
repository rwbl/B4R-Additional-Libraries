# Changelog B4R Library rMiLYWSD03MMC

### v1.00 (Build 20210620)
* NEW: Published on Anywhere Software B4R Forum Libraries [URL='https://www.b4x.com/android/forum/threads/rmilywsd03mmc-xiaomi-mi-temperature-and-humidity-monitor-2.131806/']Info[/URL]
