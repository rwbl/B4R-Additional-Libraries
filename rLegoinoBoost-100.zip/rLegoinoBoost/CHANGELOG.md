# CHANGELOG B4R Library rLegoinoBoost

### v1.00 (Build 20211018)
* NEW: First version published B4R Libraries Forum
