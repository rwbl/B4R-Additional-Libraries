# TODO rLegoinoBoost
Actions to complete till next version.
Any ideas to be captured in IDEAS.md.

### NEW: Evaluate Options to Reduce Program Space
#### Status
Not started.

### NEW: Wrap Callback for MoveHUB Green Button Press
#### Status
Not started.

### NEW: Wrap Lego Power Functions
#### Status
Not decided if will be done, because B4R library (rPowerFunctions)[https://www.b4x.com/android/forum/threads/lego-power-functions-ir-control.68464/#content] is running fine.
