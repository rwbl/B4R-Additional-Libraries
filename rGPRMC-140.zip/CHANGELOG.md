# Changelog B4R Library rGPRMC

### v1.40 (Build 20210704)
* NEW: Example LCDDisplay - Mini dashboard showing Lat/Lo position, Speed, Distance, Duration, Actual Time.
* NEW: Field UTCOffset - Set local time UTC offset. Set as parameter in module sub Initialize.
* NEW: Field SpeedMinThreshold - Speed Kmh is set to 0, if below threshold. Set as parameter in module sub Initialize.
* NEW: Sub Kmh_To_Knots - Convert Kmh to Knots
* NEW: Sub Knots_To_Kmh - Convert Knots to Kmh
* NEW: Sub Time_Difference - Calculate time difference HH MM SS between two time stamps. Used for duration calculations.
* UPD: Changed module type names T... to TGPRMC... (i.e. TDate to TGPRMCDate) to ensure Type uniqueness in list of variables/types/constants (avoid clash with other modules).
* UPD: Changed function names to separate from variable names. All function have underscores: Parse_RMC_Sentence, Distance_Between, Bearing renamed to Course_To.
* UPD: Changed Type Member TGPRMCTime.Hour to TGPRMCTime.Hours.
* UPD: All Examples.

### v1.00 (Build 20210702)
* NEW: First version, published on Anywhere Software B4R Forum Libraries [Link](https://www.b4x.com/android/forum/threads/rgprmc.132183/#post-834247).
