# Changelog B4R Library rRFXMeter

### v1.00 (Build 20220410)
* NEW: Published on Anywhere Software B4R Forum Libraries.
