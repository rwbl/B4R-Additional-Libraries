# To-Do rRFXMeter

### NEW: Example RFID
Handle RFID with cards.
#### Status
Not started.

### NEW: Example Motion Detect Device
Handle motion detect with PIR device.
#### Status
Not started.

### NEW: Example X10 Security Device
Handle x10 security detection.
#### Status
Not started.
