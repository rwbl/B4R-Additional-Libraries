# rMAX6675
rMAX6675 is an open source B4R library for the Thermosensor MAX6675 connected to microcontroller Arduino.

* Wrapper for the [MAX6675-library](https://github.com/adafruit/MAX6675-library) open source project.
* Library developed in C++ using the Arduino IDE 1.8.19 and the B4Rh2xml tool.
* B4R program examples developed with [B4R](https://www.b4x.com/b4r.html) v3.9.
* Hardware used are an Arduino UNO, MAX6675 compatible module + K Type Thermocouple Temperature Sensor 0°C-1024°C.

[B4R](https://www.b4x.com/b4r.html) development tool for native Arduino and ESP programs by [Anywhere Software](https://www.b4x.com).

## Files
* rMAX6675.zip archive contains the library and B4R sample projects.

## Install
The library files are installed in the B4R additional libraries folder.
From the zip archive, copy the content of the library folder, to the B4R additional libraries folder keeping the folder structure.
```
<path to b4r additional libraries folder>\rMAX6675.xml
<path to b4r additional libraries folder>\rMAX6675\rMAX6675.h, rMAX6675.cpp, max6675.h, max6675.cpp 
```
For B4R program examples, lookup folder Examples.

## Wiring
```
MAX6675 = Arduino
GND = GND
VCC = 5v
SCK (Serial Clock) = D10
CS (Chip Select) = D9
SO (Serial Output) = D8 
Thermosensor: RED = +, BLUE = -
```

## Methods
Initialize the MAX6675 module.
SCK - Pin Serial Clock
CS - Pin Chip Select
SO - Pin Serial Output
```
Initialize(Byte SCK, Byte CS, Byte SO)
```

Read temperature in degrees Celsius.
Returns Temperature C as double.
```
double ReadCelsius
```

Read temperature in degrees Fahrenheit.
Returns Temperature F as double.
```
double ReadFahrenheit(void);
```

## B4R Example
This basic example reads the thermosensor every 10 seconds and logs the temperature in C.
```
Sub Process_Globals
	Public serialLine As Serial
	'MAX6675
	Private maxx As MAX6675
	Private PINSCK As Byte = 10
	Private PINCS As Byte = 9
	Private PINSO As Byte = 8
	'Timer for reading
	Private timerRead As Timer
	Private READ_INTERVAL As ULong = 10000
End Sub

Private Sub AppStart
	serialLine.Initialize(115200)
	maxx.Initialize(PINSCK, PINCS, PINSO)
	timerRead.Initialize("TimerRead_Tick", READ_INTERVAL)
	timerRead.Enabled = True
	TimerRead_Tick
End Sub

Sub TimerRead_Tick
	'Temperature=20.7 Celsius
	Log("Temperature=", NumberFormat(maxx.ReadCelsius, 0, 1), " Celsius")
End Sub
```

## Credits
* Anywhere Software for providing B4R (and of course the whole B4X suite) [Info](https://www.b4x.com/).
* Open source project [MAX6675-library](https://github.com/adafruit/MAX6675-library).

## Licence
GNU General Public License v3.0.
