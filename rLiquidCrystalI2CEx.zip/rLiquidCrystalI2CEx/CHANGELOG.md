# Changelog B4R Library rLiquidCrystalI2CEx

### v1.00 (Build 20210217)
* NEW: Published on Anywhere Software B4R Forum by Anywhere Software
