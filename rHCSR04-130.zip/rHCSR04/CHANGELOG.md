# Changelog B4R Library rHCSR04

## v1.30 (Build 20210728)
* NEW: Initialize2 - Event ChangeDistance, Threshold to trigger event.
* NEW: getDistanceInch.
* NEW: Published on Anywhere Software B4R Forum Libraries (search rHCSR04).

## v1.20 (Build 20190602)
* UPD: getDistance - noInterrupts.

## v1.10 (Build 20171011)
* UPD: getDistance - added delayMicroseconds.

### v1.00 (Build 20210721)
* NEW: First version.
