# To-Do B4R Library rHCSR04
Actions to complete till next version.
Any ideas to be captured in IDEAS.md.

### NEW: Handle Multiple Sensors
Handle multiple sensors.
#### Status
Not started.

