//Library for a Traffic Light with 3 LEDs R-Y-G
//Documentation used:
//* http://playground.arduino.cc
//Additional Libraries required:
//* None
//Additional Classes required (included in the wrapped library folder):
//* None
//Changelog
//20170216: v1.0
#pragma once
#include "B4RDefines.h"
//~Author: Robert W.B. Linn
//~Version: 1.0
namespace B4R
{
	//~shortname: TrafficLight
	class B4RTrafficLight
	{
		private:
			String version = "20170216";
			Byte ledred;
			Byte ledyellow;
			Byte ledgreen;
		public:

			/**
			*Initialize the Traffic Light LEDs Red, Yellow, Green
			*Example:<code>
			*LEDs connected to the Digital Pins D8=Red, D8=Yellow, D10=Green
			*Initialize(8,9,10)
			*</code>
			*/
			void Initialize(Byte LedRedPin, Byte LedYellowPin, Byte LedGreenPin);

			/**
			*Turn the Traffic Lights Off
			*/
			void TurnOff(void);
	
			/**
			*Turn the Traffic Lights On
			*/
			void TurnOn(void);

			/**
			*Set the state for each of the LEDs Red-Yellow-Green to on = true or off = false
			*Example (Private tl As TrafficLight):<code>
			*Set Red=off,Yellow=on,Green=on: tl.State(false, true,true)
			*</code>
			*/
			void SetState(bool r, bool y, bool g);

			/**
			*Get the state for each of the LEDs Red-Yellow-Green as byte 0 (=off) or 1 (=on)
			*Returns an Array of Byte
			*Example (Private tl As TrafficLight):<code>
			*Dim b() As Byte = tl.GetState
			*Log(b.Length,":",b(0),b(1),b(2))
			*Output: 3:011 which means arraybyte length of 3, Red=Off (0), Yellow=On (1), Green=On (1)
			*/
			ArrayByte* GetState(void);

			/**
			*Set or get the state of the RED LED.
			*Example (Private tl As TrafficLight):<code>
			*'Set RED LED on (true) or off (false)
			*tl.Red = True
			*'Get the state of the RED LED
			*Log(tl.Red) returning 0 or 1
			*</code>
			*/
			void setRed(bool state);

			bool getRed();

			/**
			*Set or get the state of the YELLOW LED.
			*Example (Private tl As TrafficLight):<code>
			*'Set YELLOW LED on (true) or off (false)
			*tl.Yellow = True
			*'Get the state of the YELLOW LED
			*Log(tl.Yellow) returning 0 or 1
			*</code>
			*/
			void setYellow(bool state);

			bool getYellow();

			/**
			*Set or get the state of the GREEN LED.
			*Example (Private tl As TrafficLight):<code>
			*'Set GREEN LED on (true) or off (false)
			*tl.Green = True
			*'Get the state of the Green LED
			*Log(tl.Green) returning 0 or 1
			*</code>
			*/
			void setGreen(bool state);

			bool getGreen();

			/**
			*Simulate a Traffic Light: red 2s, yellow 3s, green 2s theen all lights turned off.
			*Example (Private tl As TrafficLight):<code>
			*Simulate
			*</code>
			*/
			void Simulate(void);

			/**
			*Get the library version.
			*Example (Private tl As TrafficLight):<code>
			*Log(tl.Version)
			*Output: 20170217
			*</code>
			*/
			B4RString* getVersion(void);

	};
}