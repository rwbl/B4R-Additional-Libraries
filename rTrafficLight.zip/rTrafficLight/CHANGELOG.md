Changelog rTrafficLight

20170216 (v1.0.0)
NEW: First version published.
