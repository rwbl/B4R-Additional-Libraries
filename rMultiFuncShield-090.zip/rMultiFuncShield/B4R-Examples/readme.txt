B4R Library rMultiFuncShield - Example Programs

