rMultiFuncShield - Library for the Arduino Multi Function Shield.
@author Robert W.B. Linn @ www.rwblinn.de
@since 20170208
@version 0.8

#Features
* 4 digit 7-segment LED display module (3641BH) driven by two serial 74HC595�s (Pin Latch 4, Clock 7, Data 8)
* 4 Red LEDs (Pin 10,11,12,13) [D1-13, D2-12, D3-11,D4-10]
* 10K potentiometer (Pin A0) [Vr-A0]
* 3 x push buttons (Pin A1, A2, A3) [S1-A1, S2-A2, S3-A3]
* Piezo buzzer (Pin 3 digital ON/OFF) [LS1-3]
* DS18B20 temperature sensor interface (not included) (Pin A4) [U5-18b20-LM35-A4]
* Infrared receiver interface (Pin 2) [U4-IR-2] Compatible to a 1838B Infrared IR receiver 
* Bluetooth interface (GND, +5v, 0 = tx, 1 = rx) [APC220]
* Free pins pwm (5,6,9,A5) with GND, +5V
* Serial interface header for connection to serial modules (Bluetooth, wireless interface, voice module, a voice recognition module)

#NOTE
Before applying power to your Arduino board check that other than the header pins, no part of the underside of this shield is in contact with the host board.

#References
Based upon this Library http://files.cohesivecomputing.co.uk/MultiFuncShield-Library.zip
Documentation used
* https://www.mpja.com/download/hackatronics-arduino-multi-function-shield.pdf
* arduinolearning.com/code/multi-function-shield-examples.php
* makbit.com/web/firmware/multi-function-shield-for-arduino/

#Wrapping
The library rMultiFuncShield depends upon the libraries to be installed TimerOne, MultiFuncShield, SoftI2C (only when I2C is used, not required for wrapping).

The wrapped library has functions to support:
* LED Display 
* LEDs
* Buzzer
* Buttons
* Temperature Sensor LM35

Sample programs developed for
LED, Buzzer, Buttons, LM35 (Temperature), DS18b20 (Temperature), PotMeter, PulseIn, Sonar HC-SR04, InlineC.

#TODO
* Wrapping is done, but requires further thorough testing
* Build some more sample programs
* Tests for later stage: I2C, InfraRed, Bluetooth APC220, Voice Recognition, MPU6050 motion sensor
