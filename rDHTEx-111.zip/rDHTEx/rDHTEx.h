//rDHTEX - B4R Library for DHT11 and DHT22 sensors.
//Wrapped from this open source library https://github.com/RobTillaart/DHTstable (https://www.arduino.cc/reference/en/libraries/dhtstable/)
//The version number of this library is the same as the wrapped library.
#pragma once
#include "B4RDefines.h"
#include "DHTStable.h"
namespace B4R {
	//~Version: 1.11
	//~Shortname: DHTEx
	//~Author: rwbl
	class B4RDHT {
		private:
			uint8_t beDHT[sizeof(DHTStable)];
			DHTStable* dht;
		public:
		
			/**
			*Initialize the DHT module.
			*/
			void Initialize();

		
			/**
			*Read value from DHT11 specified pin.
			*Pin - DHT11 data pin.
			*Returns OK, ERROR_CHECKSUM, ERROR_TIMEOUT
			*/
			int Read11(Byte Pin);

			/**
			*Read value from DHT22 specified pin.
			*Pin - DHT22 data pin.
			*Returns OK, ERROR_CHECKSUM, ERROR_TIMEOUT
			*/
			int Read22(Byte Pin);

			/**
			*Get the Humidity as Percentage.
			*Use Read11() or Read22() to refresh.
			*Returns Humidity 0 - 100% or INVALID_VALUE (-999).
			*/
			double GetHumidity();

			/**
			*Get the temperature in Celsius.
			*Use Read11() or Read22() to refresh.
			*Returns Temperature °C or INVALID_VALUE (-999).
			*/
			double GetTemperature();	
			
			/**
			*Get the IRQ state.
			*Returns true if IRQ disabled.
			*/
			bool GetDisableIRQ();
			
			/**
			*Disable the IRQ.
			*/
			void SetDisableIRQ(bool b );
			

		// Defines

		//const int DHTLIB_OK              = 0;
		#define /*int READ_OK;*/					B4RDHT_READ_OK 0
		//const int DHTLIB_ERROR_CHECKSUM  = -1;
		#define /*int READ_ERROR_CHECKSUM;*/		B4RDHT_READ_ERROR_CHECKSUM -1
		//const int DHTLIB_ERROR_TIMEOUT   = -2;
		#define /*int READ_ERROR_TIMEOUT;*/			B4RDHT_READ_ERROR_TIMEOUT -2
		//const int DHTLIB_INVALID_VALUE   = -999;
		#define /*int READ_ERROR_INVALID_VALUE;*/	B4RDHT_READ_ERROR_INVALID_VALUE -999

		//const int DHTLIB_DHT11_WAKEUP    = 18;
		#define /*int DHT11_WAKEUP;*/				B4RDHT_DHT11_WAKEUP 18
		//const int DHTLIB_DHT_WAKEUP      = 1;
		#define /*int DHT_WAKEUP;*/					B4RDHT_DHT_WAKEUP 1

	};
}