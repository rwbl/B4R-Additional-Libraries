#include "B4RDefines.h"
namespace B4R {

	void B4RDHT::Initialize(){
		dht = new (beDHT) DHTStable();
	}

	int B4RDHT::Read11(Byte Pin){
		return dht->read11(Pin);
	}
	
	int B4RDHT::Read22(Byte Pin){
		return dht->read(Pin);
	}
	
	double B4RDHT::GetHumidity(){
		return dht->getHumidity();
	}
	
	double B4RDHT::GetTemperature(){
		return dht->getTemperature();
	}

	bool B4RDHT::GetDisableIRQ(){
		return dht->getDisableIRQ();
	}
	
	void B4RDHT::SetDisableIRQ(bool b ){
		dht->setDisableIRQ(b);
	}
}