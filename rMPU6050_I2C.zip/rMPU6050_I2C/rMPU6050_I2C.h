//Library for the MPU6050 sensor
//Based upon this Library http://files.cohesivecomputing.co.uk/MultiFuncShield-Library.zip
//Documentation used
//* http://www.invensense.com/wp-content/uploads/2015/02/MPU-6000-Datasheet1.pdf
//* https://www.mpja.com/download/hackatronics-arduino-multi-function-shield.pdf
//* http://playground.arduino.cc/Main/MPU-6050
//Libraries required:
//Classes required (included in the MPU6050 folder): SoftI2C, II2C, I2C, MPU6050 
//Changelog
//20170212: v1.0
#pragma once
#include "B4RDefines.h"
#include "MPU6050.h"
//~Author: Robert W.B. Linn
//~Version: 1.0
namespace B4R {
	//~shortname: MPU6050_I2C
	/**
	*Wrapper for <link>MPU6050 motion sensor|https://www.mpja.com/download/hackatronics-arduino-multi-function-shield.pdf</link> Project. 
	*/
	class B4RMPU6050_I2C {
		private:
			MPU6050* mpu;
			uint8_t be[sizeof(MPU6050)];
		public:
			/**
			*Address pin low (GND), default for the InvenSense evaluation board
			*/
			#define /*Byte ADDRESS_AD0_LOW;*/ B4RMPU6050_I2C_ADDRESS_AD0_LOW 0x68
			
			#define /*Byte ADDRESS_AD0_HIGH;*/ B4RMPU6050_I2C_ADDRESS_AD0_HIGH 0x69 

			/**
			*Init the sensor using software I2C.
  		*Wiring: Multi Function Shield = Arduino Uno, Leonardo: SCL=pin5, SDA=pin6, Mega2560: SCL=pin5, SDA=A5.
  		*Addr - Address, set low (0x68) or high (0x69).
  		*AccelScale 0 - 3 with values 16384, 8192, 4096, 2048. Start with default 0.
  		*GyroScale 0 - 3 with values 131.072, 65.536, 32.768, 16.384. Start with default 0.
  		*Dlpf (digital low pass filter). Start with default 0.
			*Example:<code>
			*Dim mpu as MPU6050_I2C
			*InitializeSoftI2C(mpu.ADDRESS_AD0_LOW, 0,0,0)</code>
  		*/
  		void InitializeSoftI2C(Byte addr, Byte AccelScale, Byte GyroScale, Byte Dlpf);
  	
			/**
			*Init the sensor using hardware I2C.
  		*/
  		void InitializeHardI2C(Byte addr, Byte AccelScale, Byte GyroScale, Byte Dlpf);
	    
  		/**
  		*Divide raw acceleration by this value to get reading in g.
  		*/
  		Int getAccelScaleValue();

			/**
			*Divide raw gyro by this value to get degrees/second rotational velocity.
			*/
  		Double getGyroScaleValue();
  
  		/**
  		*Get raw acceleration values. Call this function prior reading the values Accel_X_Raw, Accel_Y_Raw, Accel_Z_Raw.
  		*/
  	  void GetAccelRaw();

  		Int getAccel_X_Raw();
  		Int getAccel_Y_Raw();
  		Int getAccel_Z_Raw();

  		/**
  		*Get raw gyro values. Call this function prior reading the values Gyro_X_Raw, Gyro_Y_Raw, Gyro_Z_Raw.
  		*/
  		void GetGyroRaw();

  		Int getGyro_X_Raw();
  		Int getGyro_Y_Raw();
  		Int getGyro_Z_Raw();
  		
  		/**
  		*Get temperature in 10th degrees celsius.
  		*/
  		Int GetTemp10th();

	};
}