#include "B4RDefines.h"
#include "SoftwareI2C.h"
#include "I2C.h" 

namespace B4R {
		void B4RMPU6050_I2C::InitializeSoftI2C(Byte addr, Byte AccelScale, Byte GyroScale, Byte Dlpf) {
  		mpu = new (be) MPU6050();
			SoftI2C1.initialize();
			mpu->initialize(&SoftI2C1, addr << 1, AccelScale, GyroScale, Dlpf); 
		}

		void B4RMPU6050_I2C::InitializeHardI2C(Byte addr, Byte AccelScale, Byte GyroScale, Byte Dlpf) {
  		Wire.begin();
  		I2C1.initialize(&Wire);
  		mpu->initialize(&I2C1, addr, AccelScale, GyroScale, Dlpf); 
  	}
		
		//***
		// ACCEL
		//***
    
    void B4RMPU6050_I2C::GetAccelRaw(){
	  	mpu->getAccelRaw();
    } 

  	Int B4RMPU6050_I2C::getAccel_X_Raw(){
			return mpu->accel_X_Raw / mpu->accelScaleValue;
  	}

  	Int B4RMPU6050_I2C::getAccel_Y_Raw(){
			return mpu->accel_Y_Raw / mpu->accelScaleValue;  		
  	}

  	Int B4RMPU6050_I2C::getAccel_Z_Raw(){
			return mpu->accel_Z_Raw / mpu->accelScaleValue;  		
  	}

  	Int B4RMPU6050_I2C::getAccelScaleValue(){
  		return mpu->accelScaleValue;
   	}

		//***
		// GYRO
		//***
 		
    void B4RMPU6050_I2C::GetGyroRaw(){
    	mpu->getGyroRaw();
    } 

  	Int B4RMPU6050_I2C::getGyro_X_Raw(){
  		return mpu->gyro_X_Raw / mpu->gyroScaleValue;
   	}
 
  	Int B4RMPU6050_I2C::getGyro_Y_Raw(){
  		return mpu->gyro_Y_Raw / mpu->gyroScaleValue;
  		
  	}

  	Int B4RMPU6050_I2C::getGyro_Z_Raw(){
  		return mpu->gyro_Z_Raw / mpu->gyroScaleValue;
   	}

		Double B4RMPU6050_I2C::getGyroScaleValue(){
			return mpu->gyroScaleValue;
		}

		//***
		// TEMP
		//***

  	Int B4RMPU6050_I2C::GetTemp10th(){
  		return mpu->getTemp10th();
  	}

}
