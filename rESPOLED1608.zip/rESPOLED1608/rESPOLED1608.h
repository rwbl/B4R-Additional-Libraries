//rESPOLED1608 to display text on an OLED display. There are 16 cols and 8 rows used.
//B4R Library wrapped based on project https://github.com/remoteme/esp8266-OLED. Thanks to the author.
//20190926: v1.01
#pragma once
#include "B4RDefines.h"
#include "OLED.h"
namespace B4R {
	//~Version: 1.01
	//~shortname: ESPOLED1608
	//~Author: Robert W.B. Linn
	//ESP OLED lib
	class B4RESPOLED1608 {
		private:
			OLED* ol;
			uint8_t be[sizeof(OLED)];

		public:
			//Initialize the display with SDA and SCL pin using GPIO numbering.
			//The default address of an OLED display is 0x3c.
			//Example:<code>
			//Private oledDisplay As ESPOLED1608
			//Init the OLED display with gpio4 (D2,SDA), gpio5 (D1,SCL) and default address 0x3c
			//oledDisplay.Initialize(4,5,0x3c,0)
			//oledDisplay.Print("Hello World",1,1)
			//oledDisplay.Print("Enjoy B4R",4,1)
			//</code>
  		void Initialize(int sda, int scl, int address, int offset);
		
			//Turn the display ON
			void On();
		
			//Turn the display OFF
			void Off();
		
			//Clear the display
			void Clear();
		
			//Clear a row between 0 - 7
			void Clearrow(int row);
		
			//Print a string at row and col
			//Row: 0 - 7, Col: 0 - 15
			void Print(B4RString* str, int row, int col);

	};
}