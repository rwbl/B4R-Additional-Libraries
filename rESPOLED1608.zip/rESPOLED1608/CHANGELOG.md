Changelog rESPOLED1608

20190913 (v1.00)
* NEW: First version.
