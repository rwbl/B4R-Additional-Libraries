# rESPOLED1608
rESPOLED1608 is an open source B4R library to display text on an OLED display.

Display characters in 16 columns and 8 rows on an OLED display connected to an ESP8266 microcontroller.
Can be used as a textual information display.

Tested with an 0,96 inch I2C IIC SPI serial 128 x 64 OLED LCD LED Display-Module connected to
* ESP8266 NodeMCU v1.0 microcontroller (ESP-12E module)
* ESPDuino (ESP-13 module)

This B4R Library
* is written in C++ (using the Arduino IDE 1.8.9 and the B4Rh2xml tool).
* is wrapped based on the project ESP8266 OLED library (see credits; note: made some changes/enhancements to the library).
* has been created for **personal use**  only.

[B4R](https://www.b4x.com/b4r.html) development tool for native Arduino and ESP programs by [Anywhere Software](https://www.b4x.com).

## Files
* rESPOLED1608.zip archive contains the library and sample projects.

## Install
From the zip archive, copy the content of the library folder, to the B4R additional libraries folder keeping the folder structure.

## Wiring
Sample OLED connected to  NodeMCU v1.0.

    OLED = NodeMCU
    SDA = D2 (GPIO4)
    SCL = D1 (GPIO5)
    GND = GND
    VCC = 3V3
_Note_: Checkout if the board support other pins for SDA and SCL to avoid I2C device not found message.

Tested also with an ESPDuino.
1. Put the ESPDuino in FLASH mode by pushing & keep down the FLASH button
2. Press the RST button for minimum 6 seconds
3. Release the RST and FLASH button
4. Connect the OLED to the SDA and SCL pins (right from the RST and FLASH buttons)
5. Upload the program
6. Press the RST button to reset the ESPDuino

The ESPDuino has dedicated SDA (GPIO4) and SCL (GPIO5) pins.

## I2C Address

    0x3c
This is the default address. Check out with an I2C scanner for the device address.

## Object
Declare the Object referring to the library.

    Private oledDisplay As ESPOLED1608

## Library Functions

### oledDisplay.Initialize(sda as Int, scl as Int, address as Int, offset as Int)
Initialize the display with sda & scl pin (GPIO numbering).
Default address of an OLED is 0x3C.
Leave the offset to 0.

### oledDisplay.On
Turn the display ON.

### oledDisplay.Off
Turn the display OFF.

### oledDisplay.Clear
Clear the display.

### oledDisplay.Clearrow(Row as Int)
Clear a row between 0 - 7

### oledDisplay.Print(Str as String, Row as Int, Col as Int)
Print a string at row and col
Row: 0 - 7, Col: 0 - 15

## B4R Example
Hardware: ESP8266 NodeMCU 1.0.
```
#Region Project Attributes
	#AutoFlushLogs: True
	#CheckArrayBounds: True
	#StackBufferSize: 300
#End Region

Sub Process_Globals
	'Serial
	Public serialLine As Serial
	Private serialLineBaudRate As ULong = 115200
	Private oledDisplay As ESPOLED1608
End Sub

Private Sub AppStart
	serialLine.Initialize(serialLineBaudRate)
	Log("AppStart")
	'Init the OLED display with gpio4 (D2,SDA), gpio5 (D1,SCL) and default address 0x3c
	oledDisplay.Initialize(4,5,0x3c,0)
	'Clear the display (although already cleared but to show the function)
	oledDisplay.Clear
	'Print at row 1, col 1
	oledDisplay.Print("Hello World",1,1)
	'Print at row 4, col 1
	oledDisplay.Print("Enjoy B4R",4,1)
	'Print at row 7, col 1
	oledDisplay.Print("Thank You...",7,1)
End Sub
```

## Credits
* Anywhere Software for providing B4R (and of course the whole B4X suite) [Info](https://www.b4x.com/)
* remoteme for the ESP8266 OLED library [Info](https://github.com/remoteme/esp8266-OLED)
* Friends-of-Fritzing foundation for fritzing [Info](https://fritzing.org)

## Licence
GNU General Public License v3.0.
