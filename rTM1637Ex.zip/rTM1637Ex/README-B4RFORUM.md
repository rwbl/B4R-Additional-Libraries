[B]rTM1637Ex[/B] is an open source B4R library for writing to TM1637 7-segment-displays connected to microcontroller, like Arduino.

The library provides extended methods based on the library [URL='https://www.b4x.com/android/forum/threads/tm1637-4-digits-display.67733/#post-477687']rTM1637[/URL] and has been tested with B4R v3.5.

[B]Attached[/B]
rTM1637Ex.zip archive contains the library and B4R sample projects.

[B]Install[/B]
The library files are installed in the B4R additional libraries folder.
From the zip archive, copy the content of the library folder, to the B4R additional libraries folder keeping the folder structure.
[CODE=b4x]
<path to b4r additional libraries folder>\rTM1637Ex.xml
<path to b4r additional libraries folder>\rTM1637Ex\rTM1637Ex.h , rTM1637Ex.cpp, TM1637Display.h , TM1637Display.cpp
[/CODE]

[B]Wiring
TM1637 = Arduino[/B]
CLK = D2
DIO = D3
GND = GND
VCC = 3.3v or 5v

Tested a DFRobot 4-Digit Display v1.0 (supports semicolon, but no dot) with the Arduino UNO and Arduino MEGA.

[B]Functions Overview
Initializes Display Object [/B]
PinClk - Pin connected to the clock pin.
PinDIO - Pin connected to the DIO pin.
[CODE=b4x]
Initialize (PinClk As Byte, PinDIO As Byte)
[/CODE]

[B]Set Display Brightness[/B]
The setting takes effect when a command is given to change the data being displayed.
brightness - a number from 0 (lowes brightness) to 7 (highest brightness)
on - turn display on or off
[CODE=b4x]
SetBrightness (brightness As Byte, on As bool)
[/CODE]

[B]Display Arbitrary Data[/B]
Each byte represents a single digit. Each bit represents a segment.
Position - Position from which to start the modification (0 - leftmost, 3 - rightmost).
The 7 LED segments A F B G E C D. DP is the dot (8th LED) if supported by the display.
[CODE=b4x]
SetSegments (Segments As Byte[], Position As Byte)
[/CODE]

[B]Display Decimal Number[/B]
[CODE=b4x]
ShowNumberDec (Number As Int)
[/CODE]

[B]Display Decimal Number with Options[/B]
Number - Number to be shown.
LeadingZero - Whether to add leading zeroes.
Length - Number of digits to set.
Position - Position of the least significant digit (0 - leftmost, 3 - rightmost).
[CODE=b4x]
ShowNumberDec2 (Number As Int, LeadingZero As bool, Length As Byte, Position As Byte)
[/CODE]

[B]Display Decimal Number with DotMask[/B]
Controls the decimal dots or colon based on the DotsMask.
Pass 0xFF to enable all dots / colons.
The argument is a bitmask, with each bit corresponding to a dot between the digits (or colon mark, as implemented by each module).
The MSB is the leftmost dot of the digit being update.
For example, if Position is 1, the MSB of DotsMask will correspond the dot near digit no. 2 from the left.
Dots are updated only on those digits actually being update (that is, no more than Length digits)
[CODE=b4x]
ShowNumberDec3 (Number As Int, LeadingZero As bool, Length As Byte, Position As Byte, DotsMask As Byte)
[/CODE]

[B]Clear Display[/B]
(uses the method SetSegments with 0 data)
[CODE=b4x]
Clear()
[/CODE]

[B]Get Char[/B]
Get Char from the font char table.
Index - AscII character index 0 - 127
Font - 1=AscII, 2=Siekoo
[CODE=b4x]
Byte GetChar(Int Index, Byte Font)
[/CODE]

[B]Display Text[/B]
Display a text with max 4 characters in ascii range 0-127. Not all characters are supported.
Position - Starting position of the text: 0=leftmost .. 3=rightmost
Font - 1=AscII, 2=Siekoo
Examples:
Display text HaLo startig at pos 0 (leftmost): tmDisplay.ShowText("HaLo",0)
Display text 9C starting at position 1: tmDisplay.ShowText("9C",1)
[CODE=b4x]
ShowText(B4RString* Text, Byte Position, Byte Font);
[/CODE]

[B]Fields[/B]
[I]Segments[/I]
Define the 7 segments
The segment definitions are used to define the character tables and for the method SetSegments.
[CODE=b4x]
SEG_A, SEG_B, SEG_C, SEG_D, SEG_E, SEG_F, SEG_G
[/CODE]

[I]Fonts[/I]
Two fonts are supported:
[CODE=b4x]
FONT_ASCII - AscII characters 0 - 127.
FONT_SIEKOO - AscII characters 0 - 127 displayed as Siekoo font.
[/CODE]

[I]Special Characacter[/I]
Example library header file, how to define a special character using the 7 segment fields:
[CODE=b4x]
#define /*Byte SPECIAL_DEGREE;*/ B4RTM1637Display_SPECIAL_DEGREE SEG_A | SEG_B | SEG_F | SEG_G
[/CODE]

[B]B4R Example Blinking Number[/B]
Several examples showing a blinking number.
[CODE=b4x]
Sub Process_Globals
    Public VERSION As String = "B4R Library rTM1637Ex - Blinking Number v20210216"
    Public serialLine As Serial
    Private tmDisplay As TM1637Display
    Private PINCLK As Byte = 2
    Private PINDIO As Byte = 3
    Private BRIGHTNESS As Byte = 7
    Private timerBlinking As Timer
    Private TIMERBLINKING_INTERVAL As ULong = 2000
    Private displayOn As Boolean = False
End Sub

Private Sub AppStart
    serialLine.Initialize(115200)
    Log(VERSION)
    ' Init display with pin clk and dio
    tmDisplay.Initialize(PINCLK, PINDIO)
    ' Set the blnking timer
    timerBlinking.Initialize("TimerBlinking_Tick", TIMERBLINKING_INTERVAL)
    timerBlinking.Enabled = True
    tmDisplay.Clear
End Sub

Sub TimerBlinking_Tick
    Dim numberValue As Int
    displayOn = Not(displayOn)

    ' Set the display brightness and turn the display ON or OFF
    tmDisplay.SetBrightness(BRIGHTNESS, displayOn)
    tmDisplay.Clear
  
    ' Show two digit random number NN with length 2 at the right
    numberValue = Rnd(0,99)
    tmDisplay.ShowNumberDec2(numberValue, False, 2, 2)

    ' Show two digit random number NNNN with leading zeros from left to right
    ' numberValue = Rnd(0,1001)
    ' tmDisplay.ShowNumberDec2(numberValue, True, 4, 0)

    ' Show four digit random number NNNN with leading zeros from left to right with semicolon between NN:NN
    ' numberValue = Rnd(1,1001)
    ' tmDisplay.ShowNumberDec3(numberValue, True, 4, 0, 0xFF)

    Log(numberValue, " = " , displayOn)
End Sub
[/CODE]

[B]B4R Example SetSegments[/B]
The display to show rightmost 9°C.
The degree character and the letter C are created using the method SetSegments.
[CODE=b4x]
Sub Process_Globals
    Public VERSION As String = "B4R Library rTM1637Ex - SetSegments v20210216"
    Public serialLine As Serial
    Private tmDisplay As TM1637Display
    Private PINCLK As Byte = 2
    Private PINDIO As Byte = 3
End Sub

Private Sub AppStart
    serialLine.Initialize(115200)
    Log(VERSION)
    tmDisplay.Initialize(PINCLK, PINDIO)
  
    'Clear the display first
    tmDisplay.Clear

    'Set a single digit number (9) at position 1
    tmDisplay.ShowNumberDec2(9,False,1,1)
  
    'Show °C (circle C) at position 2 (from left) using setsegments
    Dim circle As Byte = Bit.Or(tmDisplay.SEG_A, Bit.Or(tmDisplay.SEG_B, Bit.Or(tmDisplay.SEG_F, tmDisplay.SEG_G)))
    Dim celcius As Byte = Bit.Or(tmDisplay.SEG_A, Bit.Or(tmDisplay.SEG_D, Bit.Or(tmDisplay.SEG_E, tmDisplay.SEG_F)))
    tmDisplay.SetSegments(Array As Byte(circle, celcius), 2)
End Sub
[/CODE]

[B]B4R Siekoo Example (snippet)[/B]
Display special degree character, AscII 94 with Siekoo font at position
[CODE=b4x]
Private charFont As Byte = 2 ' Siekoo
Private charPos As Byte = 3 ' most right
tmDisplay.SetSegments(Array As Byte(tmDisplay.GetChar(94, charFont)), charPos)
[/CODE]

[B]Hints[/B]
If not using the Siekoo font, remove from the library - saves memory.

[B]Licence[/B]
GNU General Public License v3.0.

[B]Changelog[/B]
v1.50 (20210525) - GetChar, ShowText, Fonts AscII & Siekoo, Improvements
v1.00 (20210217) - Initial version
