# Changelog B4R Library rTM1637Ex

### v1.50 (Build 20210525)
* NEW: ShowText - Display up to 4 characters or symbols
* NEW: Font - AscII or Siekoo
* NEW: GetChar - Select char as byte
* NEW: Examples - Show text with AscII or Siekoo font, SetSegments own symbols
* UPD: Various minor improvements

### v1.00 (Build 20210217)
* NEW: Published on Anywhere Software B4R Forum Libraries.
