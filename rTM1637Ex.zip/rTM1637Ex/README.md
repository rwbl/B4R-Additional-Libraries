# rTM1637Ex
rTM1637Ex is an open source B4R library for writing to TM1637 seven-segment-displays connected to microcontroller, like Arduino.

This B4R library
* is a wrapper for the [open source project](https://github.com/avishorp/TM1637).
* is based on the library [rTM1637](https://www.b4x.com/android/forum/threads/tm1637-4-digits-display.67733/#post-477687) by Anywhere Software].
* is written in C++ (using the Arduino IDE 1.8.13 and the B4Rh2xml tool).

[B4R](https://www.b4x.com/b4r.html) development tool for native Arduino and ESP programs by [Anywhere Software](https://www.b4x.com).

## Files
* rTM1637Ex.zip archive contains the library and sample projects.

## Install
The library files are installed in the B4R additional libraries folder.
From the zip archive, copy the content of the library folder, to the B4R additional libraries folder keeping the folder structure.
```
<path to b4r additional libraries folder>\rTM1637Ex.xml
<path to b4r additional libraries folder>\rTM1637Ex\rTM1637Ex.h , rTM1637Ex.cpp, TM1637Display.h , TM1637Display.cpp 
```

## Wiring
```
TM1637 = Arduino
CLK = D2 
DIO = D3 
GND = GND
VCC = 3.3v or 5v
```
Tested with an Arduino UNO and Arduino MEGA.

## Functions Overview
Initializes the object.
```
Initialize(Byte PinClk, Byte PinDIO)
```

Sets the brightness of the display.
```
SetBrightness(Byte brightness, bool on); 
```

Display Segment
```
SetSegments(ArrayByte* Segments, Byte Position);
```

// Define the 7 segments for function SetSegments
SEG_A, SEG_B, SEG_C, SEG_D, SEG_E, SEG_F, SEG_G

Display decimal number
```
void ShowNumberDec(Int Number);
```

Display decimal number with leading zeros for a given length at position.
```
ShowNumberDec2(Int Number, bool LeadingZero, Byte Length, Byte Position);
```

Display decimal number with leading zeros for a given length at position with dotmask option.
```
ShowNumberDec3(Int Number, bool LeadingZero, Byte Length, Byte Position, Byte DotsMask);
```

Clear the display (uses SetSegments with 0 data)
```
Clear();
```

## B4R Example Blinking Number
```
#Region Project Attributes
	#AutoFlushLogs: True
	#CheckArrayBounds: True
	#StackBufferSize: 300
#End Region

Sub Process_Globals
	Public VERSION As String = "B4R Library rTM1637Ex - Blinking Number v20210216"
	Public serialLine As Serial
	Private tmDisplay As TM1637Display
	Private PINCLK As Byte = 2
	Private PINDIO As Byte = 3
	Private BRIGHTNESS As Byte = 7
	Private timerBlinking As Timer
	Private TIMERBLINKING_INTERVAL As ULong = 2000
	Private displayOn As Boolean = False
End Sub

Private Sub AppStart
	serialLine.Initialize(115200)
	Log(VERSION)
	' Init display with pin clk and dio
	tmDisplay.Initialize(PINCLK, PINDIO)
	' Set the blnking timer
	timerBlinking.Initialize("TimerBlinking_Tick", TIMERBLINKING_INTERVAL)
	timerBlinking.Enabled = True
	tmDisplay.Clear
End Sub

Sub TimerBlinking_Tick
	Dim numberValue As Int
	displayOn = Not(displayOn)

	' Set the display brightness and turn the display ON or OFF
	tmDisplay.SetBrightness(BRIGHTNESS, displayOn)
	tmDisplay.Clear
	
	' Show two digit random number NN with length 2 at the right
	numberValue = Rnd(0,99)
	tmDisplay.ShowNumberDec2(numberValue, False, 2, 2)

	' Show two digit random number NNNN with leading zeros from left to right
	' numberValue = Rnd(0,1001)
	' tmDisplay.ShowNumberDec2(numberValue, True, 4, 0)

	' Show four digit random number NNNN with leading zeros from left to right with semicolon between NN:NN
	' numberValue = Rnd(1,1001)
	' tmDisplay.ShowNumberDec3(numberValue, True, 4, 0, 0xFF)

	Log(numberValue, " = " , displayOn)

End Sub
```

## Hints

### How to show semicolon character ":"?
For Sub ShowNumberDec3, pass argument 5: 0xFF = show colon, 0x00 = hide colon
Arguments:
*Number - Number to be shown.
*LeadingZero - Whether to add leading zeroes.
*Length - Number of digits to set.
*Position - Position of the least significant digit (0 - leftmost, 3 - rightmost).
*Decimal dots or colon based on the DotsMask. Pass 0xFF to enable all dots / colons or 0x00 to disable.
```
'Show number 1234 with semicolon.
tm.ShowNumberDec3(1234, False, 4, 0, 0xFF) 
```

## Credits
* Anywhere Software for providing B4R (and of course the whole B4X suite) [Info](https://www.b4x.com/).
* Author of this [open source project](https://github.com/avishorp/TM1637).

## Licence
GNU General Public License v3.0.
