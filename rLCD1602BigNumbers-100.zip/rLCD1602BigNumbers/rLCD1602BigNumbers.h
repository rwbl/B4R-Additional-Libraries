// B4R Library to display Big Numbers on a LCD1602.
// Changelog
// 20170131: NEW
#pragma once
#include "B4RDefines.h"
#include "rLiquidCrystal.h"
#include "LCD1602BigNumbers.h"
namespace B4R {
	//~Version: 1.0
	//~shortname: LCD1602BigNumbers
	class B4RLCD1602BigNumbers {
		private:
			LCD1602BigNumbers* bn;
			uint8_t be[sizeof(LCD1602BigNumbers)];
		public:
			/**
			*Initializes the object with the LCD display from library rLiquidCrystal (must be initialized prior initializing big numbers).
			*Max 4 numbers can be displayed.
			*Example:<code>
			*Private lcd As LiquidCrystal
			*Private bigNum As LCD1602BigNumbers
			*bigNum.Initialize(lcd)</code>
			*/
  		void Initialize(B4RLiquidCrystal* lcd);
				
			/**
			*Writes a number 0 - 9 at given column position.
			*A number has size of 3 columns width and 2 row height. Max column position is 13.
			*Example displaying number 9 at column 3:<code> 
			*WriteBigNumber(9, 3)</code>
			*/
			void WriteBigNumber(byte number, byte col);
	};

}