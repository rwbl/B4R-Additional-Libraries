/*
  LCD1602BigNumbers.cpp - Library for displaying large numbers on LCD1602 displays.
  @see LCD1602BigNumbers.h
*/

#include "LCD1602BigNumbers.h"

// Define 8 arrays holding the 5x8 pixels for the 8 customized characters, which are used to create a large number.
byte customchar[8][8] = {
    {
				//Top Bar
        B11111,
        B11111,
        B11111,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
    }, {
				//Bottom Bar
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B11111,
        B11111,
        B11111
    }, {
				//Top & Bottom Bar
        B11111,
        B11111,
        B11111,
        B00000,
        B00000,
        B11111,
        B11111,
        B11111
    }, {
				//Bottom Middle Bar
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B01110,
        B01110,
        B01110
    }, {
				//Middle Middle Bar
        B00000,
        B00000,
        B00000,
        B01110,
        B01110,
        B01110,
        B00000,
        B00000
    }, {
				//Empty Bar
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
    }, {
				//Empty Bar
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
    }, {
				//Empty Bar
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000,
        B00000
    }
};

// Define the 10 big numbers 0 - 9. Each number has a 2 rows height and 3 columns width.
// A numbers is created by defining for each row and its 3 columns a custom character in an 3 dimentional array [number], [row], [cell]
// The values are:
// 	0 - 9 as defined by the previous custom char array. Mainly array members 0,1,2 are used.
//  255 filling a column
// 	254 empty column
// Example for number 1 is:
// Row 1: Cell 1 = custom char 0, Cell 2 = Filled, Cell 3 = Empty
// Row 2: Cell 1 = custom char 1, Cell 2 = Filled, Cell 3 = custom char 1
byte bignumbers[10][2][3] = {
    {
				// Number 0
        {255, 0, 255},
        {255, 1, 255}
    }, {
				// Number 1
        {0, 255, 254},
        {1, 255, 1}
    }, {
				// Number 2
        {2, 2, 255},
        {255, 1, 1}
    }, {
				// Number 3
        {0, 2, 255},
        {1, 1, 255}
    }, {
				// Number 4
        {255, 1, 255},
        {254, 254, 255}
    }, {
				// Number 5
        {255, 2, 2},
        {1, 1, 255}
    }, {
				// Number 6
        {255, 2, 2},
        {255, 1, 255}
    }, {
				// Number 7
        {0, 0, 255},
        {254, 255, 254}
    }, {
				// Number 8
        {255, 2, 255},
        {255, 1, 255}
    }, {
				// Number 9
        {255, 2, 255},
        {254, 254, 255}
    }
};

// Creates the LCD1602BigNumbers object.
// Parameter:
// LiquidCrystal* lcd: LiquidCrystal object to use which must be initialized prior using
LCD1602BigNumbers::LCD1602BigNumbers(LiquidCrystal* lcd)
{
  _lcd = lcd;
}

// Loads the custom characters used to build the big numbers 0 - 9
void LCD1602BigNumbers::begin()
{
	for (int i = 0; i < 8; i++)
		_lcd->createChar(i, customchar[i]);
    _lcd->home();
}

// Writes a number 0 - 9 at position col over the 2 rows
// Parameter:
// number - the number to display
// col - column of upper left corner of first large character
void LCD1602BigNumbers::writeBigNumber(byte number, byte col) {
		// Do nothing if number out of range
    if (number > 9) return;
		// Set the row to 0
		byte row = 0;
		// Build the big number over 2 rows
    for (int i = 0; i < 2; i++) {
        _lcd->setCursor(col, row + i);
        // Fill the 3 columns using the bignumbers 3 dimentional array number, row, cell
        for (int j = 0; j < 3; j++) {
            _lcd->write(bignumbers[number][i][j]);
        }
				// Write empty cell as separator between big numbers
        _lcd->write(254);
    }
		// Move the cursor to the next custom char position
    _lcd->setCursor(col + 4, row);
}
