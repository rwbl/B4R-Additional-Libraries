//@see rLCD1602BigNumbers.h for details
#include "B4RDefines.h"
namespace B4R {
		void B4RLCD1602BigNumbers::Initialize(B4RLiquidCrystal* lcd){
			//uses rLiquidCrystal.h to get the lc member (which is LiquidCrytal)
			bn = new (be) LCD1602BigNumbers(lcd->lc); 
			bn->begin();  			
  	};
  	
  	void B4RLCD1602BigNumbers::WriteBigNumber(byte number, byte col){
  		bn->writeBigNumber(number, col);
  	};
}
