/*
  LCD1602BigNumbers - Library for displaying large numbers on LCD1602 displays.
 	Based on some Arduino code examples.
  @author Robert W.B. Linn @ www.rwblinn.de
  @since 20170130
*/

#ifndef LCD1602BigNumbers_h
#define LCD1602BigNumbers_h

#include "Arduino.h"
#include "LiquidCrystal.h"

class LCD1602BigNumbers
{
  public:
    LCD1602BigNumbers(LiquidCrystal*);
  	void begin();
		void writeBigNumber(byte number, byte col);
  private:
    LiquidCrystal* _lcd;
};

#endif
