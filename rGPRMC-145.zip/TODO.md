# To-Do rGPRMC
Actions to complete till next version.
Any ideas to be captured in IDEAS.md.

### NEW: Test MakerHawk GPS Module connected to an ESP32
Connect the MakerHawk GPS module to an ESP32 and sent data in MQTT format.
#### Status
Not started.

### Improve accuracy of distance & course to
This depends on the microcontroller.
Build the library with an Arduino UNO - Double = Float = 4 Bytes.
Next: test with an ESP32 or Arduino Leonardo.
#### Status
Not started.

### Checkout how to use the onboard E2PROM and the serial port
#### Status
Not started.
