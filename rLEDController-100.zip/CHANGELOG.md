# Changelog B4R Library rLEDController

### v1.00 (Build 20210721)
* NEW: First version, published on Anywhere Software B4R Forum Libraries [Link](https://www.b4x.com/android/forum/threads/rgprmc.132183/#post-834247).
