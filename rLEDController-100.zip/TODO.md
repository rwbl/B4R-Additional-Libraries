# To-Do rLEDController
Actions to complete till next version.
Any ideas to be captured in IDEAS.md.

### NEW: LED Set Brightness
Set the brightness of an LED connected to PWM pin.
#### Status
Not started.

